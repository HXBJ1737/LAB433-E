//
// Created by 李 on 2023/8/5.
//

#ifndef PICTURE_SHOOT_KEY_H
#define PICTURE_SHOOT_KEY_H
#include "main.h"
#include "tim.h"

void pro_sta();

#endif //PICTURE_SHOOT_KEY_H
