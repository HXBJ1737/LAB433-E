//
// Created by 李 on 2023/8/5.
//

#include "key.h"

extern uint8_t key_num;

extern uint16_t gpio_pin;

void pro_sta()
{
    HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,GPIO_PIN_RESET);
    HAL_Delay(500);
    HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,GPIO_PIN_SET);
    HAL_GPIO_WritePin(beep_GPIO_Port,beep_Pin,GPIO_PIN_SET);
    HAL_Delay(500);
    HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,GPIO_PIN_RESET);
    HAL_GPIO_WritePin(beep_GPIO_Port,beep_Pin,GPIO_PIN_RESET);
    HAL_Delay(500);
    HAL_GPIO_WritePin(LED_GPIO_Port,LED_Pin,GPIO_PIN_SET);
    HAL_GPIO_WritePin(beep_GPIO_Port,beep_Pin,GPIO_PIN_SET);
};

void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
    HAL_TIM_Base_Start_IT(&htim4);
    gpio_pin = GPIO_Pin;
}

void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
    HAL_TIM_Base_Stop_IT(&htim4);
    if (HAL_GPIO_ReadPin(GPIOD,gpio_pin)==GPIO_PIN_RESET)
    {
        if (gpio_pin == GPIO_PIN_8)
        {
            key_num = 1;
        }
        else if (gpio_pin == GPIO_PIN_9)
        {
            key_num = 2;
        }
        else if (gpio_pin == GPIO_PIN_10)
        {
            key_num = 3;
        }
    }
}
