//
// Created by 李 on 2023/8/4.
//

#ifndef PICTURE_SHOOT_SERVO_H
#define PICTURE_SHOOT_SERVO_H

#include "main.h"

//#include "tim.h"

//#include "gpio.h"

//void change_angle(float *angle);
//void change_char(float *angle,char *arr);
float* change_char(float *angle,char *arr);
void change_angle(float *angle);
void reset();
void go_around();
#endif //PICTURE_SHOOT_SERVO_H
