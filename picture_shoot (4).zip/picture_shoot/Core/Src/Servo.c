//
// Created by 李 on 2023/8/4.
//

#include "Servo.h"
#include "tim.h"
#include "retarget.h"
//up channel1 PE9
extern float last_up_pwm ;
extern float last_down_pwm ;

extern  float up_angle ;
extern  float low_angle ;
//void change_angle(float *angle)

void change_angle(float *angle)
{
    float up_pwm,down_pwm;


    //舵机角度转换PWM
//    up_pwm = (angle[1]/180) * 2000 ;
//    down_pwm = (angle[0]/270) * 2000 ;

    up_pwm = -((angle[1]/180.0) * 2000) ;
    printf(" up_pwm %f\r\n",up_pwm);

    down_pwm = -((angle[0]/270.0) * 2000) ;
    printf("down_pwm %f \r\n",down_pwm);
    //限幅

    last_up_pwm = up_pwm + last_up_pwm;
    last_down_pwm = down_pwm + last_down_pwm;


    if((last_up_pwm) > 2500) up_pwm = 2500;
    if(last_up_pwm <500) up_pwm = 500;
    if(last_down_pwm>2500) down_pwm = 2500;
    if(last_down_pwm<500)  down_pwm = 500;

   // printf("%f    %f",angle[0],angle[1]);
   // printf("%f    %f",up_pwm,down_pwm);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,last_up_pwm); //上舵机 垂直
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_2,last_down_pwm);//下舵机 水平

}

 float* change_char(float *angle,char *arr)
{
    // a :97
    // b :98

    uint32_t num1_1,num1_2;
    uint32_t num2_1,num2_2;
    num1_1 = (uint32_t)arr[2] - 48;
    num1_2 = (uint32_t)arr[4] - 48;

    num2_1 = (uint32_t)arr[6] - 48;
    num2_2 = (uint32_t)arr[8] - 48;
    if((uint32_t)arr[1] == 97)
    {
        angle[0] = num1_1 + 0.1*num1_2;
//         low_angle  = num1_1 + 0.1*num1_2 ;

    }
    if((uint32_t)arr[1] == 98)
    {
        angle[0] = -(num1_1 + 0.1*num1_2);
//        low_angle  = - (num1_1 + 0.1*num1_2) ;
    }
    if((uint32_t)arr[5] == 97)
    {
        angle[1] = num2_1 + 0.1*num2_2;
//        up_angle = num2_1 + 0.1*num2_2;

    }
    if((uint32_t)arr[5] == 98)
    {
      angle[1] = -(num2_1 + 0.1*num2_2);
//        up_angle = -(num2_1 + 0.1*num2_2);
    }

    return angle;
}

void reset()
{
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,up_far);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_2,down_far);
    HAL_Delay(1000);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,up_start);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_2,down_start);
    last_up_pwm = up_start;
    last_down_pwm = down_start;
}

void go_around()
{

    reset();
    HAL_Delay(1000);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,l_d_u);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_2,l_d_d);
    HAL_Delay(1000);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,l_u_u);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_2,l_u_d);
    HAL_Delay(1000);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,r_u_u);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_2,r_u_d);
    HAL_Delay(1000);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,r_d_u);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_2,r_d_d);
    HAL_Delay(1000);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_1,l_d_u);
    __HAL_TIM_SET_COMPARE(&htim1,TIM_CHANNEL_2,l_d_d);
    HAL_Delay(1000);
}

